from django.shortcuts import render,redirect

from django.views.generic import View

from notes.forms import TaskForm,RegistrationForm,SignInForm

from notes.models import Task

from django.contrib import messages

from django import forms

from django.contrib.auth.models import User

from django.contrib.auth import authenticate,login,logout

from django.db.models import Q

from notes.decorators import signin_required

from django.utils.decorators import method_decorator

from django.views.decorators.cache import never_cache


@method_decorator([signin_required,never_cache],name="dispatch")
class TaskCreateView(View):
    def get(self,request,*args,**kwargs):

        form_instance=TaskForm()


        return render(request,"task_create.html",{"form":form_instance})
    

    def post(self,request,*args,**kwargs):

        form_instance=TaskForm(request.POST)

        if form_instance.is_valid():  

            form_instance.instance.user=request.user   
           

            form_instance.save()



            messages.success(request,"task has been added")

            return redirect("task-list")
        else:
            messages.error(request,"task has not been added")
            return render(request,"task_create.html",{"form":form_instance})

        

@method_decorator([signin_required,never_cache],name="dispatch")
class TaskListView(View):

    def get(self,request,*args,**kwargs):
       
       if not request.user.is_authenticated:
           print("invaild session")

           return redirect("sign-in")
       
       search_text=request.GET.get("search_text")

       selected_category=request.GET.get("category","all")


       if  selected_category =="all":
            qs=Task.objects.filter(user=request.user)

       else:
            qs=Task.objects.filter(category=selected_category,user=request.user)


       if search_text!=None:
           
           qs=Task.objects.filter(user=request.user)
           
           qs=qs.filter(Q(title__contains=search_text)|Q(description__contains=search_text))


       return render(request,"task_list.html",{"task":qs,"selected":selected_category})

           








@method_decorator([signin_required,never_cache],name="dispatch")
class TaskDetailView(View):
    def get(self,request,*args,**kwargs):

        id=kwargs.get("pk")

        qs=Task.objects.get(id=id)

        return render(request,"task_detail",{"task":qs})

    
@method_decorator([signin_required,never_cache],name="dispatch")
class TaskUpdateView(View):

    def get(self,request,*args,**kwargs):

        id=kwargs.get("pk")

        qs=Task.objects.get(id=id)

        form_instance=TaskForm(instance=qs)

        # adding status field to form_instance

        form_instance.fields["status"]=forms.ChoiceField(choices=Task.status_choices,widget=forms.Select(attrs={"class":"form-control form-select"}))

        return render(request,"task_update.html",{"form":form_instance})
    

    
    
    def post(self,request,*args,**kwargs):

        id=kwargs.get("pk")

        form_instance=TaskForm(request.POST)

        if form_instance.is_valid():

            data=form_instance.cleaned_data

            # extract status from request.POST
            status=request.POST.get("status")

            qs=Task.objects.filter(id=id).update(**data,status=status)

            return redirect("task-list")
        

        else:
            
            return render(request,"task_update.html",{"form":form_instance})
        
       
@method_decorator([signin_required,never_cache],name="dispatch")
class TaskDeleteView(View):
    def get(self,request,*args,**kwargs):

        id=kwargs.get("pk")
        qs=Task.objects.get(id=id).delete()
        return redirect("task-list")




@method_decorator([signin_required,never_cache],name="dispatch")
class TaskSummaryView(View):
    def get(self,request,*args,**kwargs):
        qs=Task.objects.filter(user=request.user)

        total_task_count=qs.count()
        
        return render(request,"task_summary.html",{ "total_task_count":total_task_count})

        

        
class SignUpView(View):
    def get(self,request,*args,**kwargs):

        form_instance=RegistrationForm()

        return render(request,"register.html",{"form":form_instance})
    

    
    
    def post(self,request,*args,**kwargs):

        form_instance=RegistrationForm(request.POST)

        if form_instance.is_valid():
          
          

          data=form_instance.cleaned_data


          User.objects.create_user(**data)

          return redirect("sign-in")
        else:
            return render(request,"register.html",{"form":form_instance})
    


class SignInView(View):
    def get(self,request,*args,**kwargs):
         
        form_instance=SignInForm()

        return render(request,"login.html",{"form":form_instance})
    

    def post(self,request,*args,**kwargs):

        form_instance=SignInForm(request.POST)

        if form_instance.is_valid():

            username=form_instance.cleaned_data.get("username")

            password=form_instance.cleaned_data.get("password")


            user_object=authenticate(request,username=username,password=password)

            if user_object:

                login(request,user_object)

                return redirect("task-list")
            
        else:
            return render(request,"login.html",{"form":form_instance})
        


@method_decorator([signin_required,never_cache],name="dispatch")
class SignOutView(View):
    def get(self,request,*args,**kwargs):

        logout(request)    

        return redirect("sign-in")    


    

class DashBoardView(View):

    def get(self,request,*args,**kwrags):
        return render(request,"dash_board.html")
     


         

